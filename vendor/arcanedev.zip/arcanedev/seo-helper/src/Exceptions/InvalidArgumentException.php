<?php namespace Arcanedev\SeoHelper\Exceptions;

/**
 * Class     InvalidArgumentException
 *
 * @package  Arcanedev\SeoHelper\Exceptions
 * @author   ARCANEDEV <arcanedev.maroc@gmail.com>
 */
class InvalidArgumentException extends SeoHelperException {}
