<?php namespace Arcanedev\SeoHelper\Exceptions;

/**
 * Class     SeoHelperException
 *
 * @package  Arcanedev\SeoHelper\Exceptions
 * @author   ARCANEDEV <arcanedev.maroc@gmail.com>
 */
abstract class SeoHelperException extends \Exception {}
