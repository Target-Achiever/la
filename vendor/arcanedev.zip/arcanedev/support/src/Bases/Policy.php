<?php namespace Arcanedev\Support\Bases;

/**
 * Class     Policy
 *
 * @package  Arcanedev\Support\Bases
 * @author   ARCANEDEV <arcanedev.maroc@gmail.com>
 */
abstract class Policy
{
    //
}
