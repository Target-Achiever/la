<?php namespace Arcanedev\Support\Exceptions;

/**
 * Class     RouteNamespaceUndefinedException
 *
 * @package  Arcanedev\Support\Exceptions
 * @author   ARCANEDEV <arcanedev.maroc@gmail.com>
 */
class RouteNamespaceUndefinedException extends \Exception {}
