<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AlterUserTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('users', function ($table) {
			$table->string('photo');
			$table->enum('user_status', ['active', 'in_active'])->after('password');
			$table->enum('user_type', ['super_admin', 'end_user', 'prescriber', 'non_prescriber'])->after('password');
		});
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('users', function ($table) {
			$table->enum('user_status', ['active', 'in_active'])->after('password');
			$table->enum('user_type', ['end_user', 'prescriber', 'non_prescriber'])->after('password');
		});
    }
}
